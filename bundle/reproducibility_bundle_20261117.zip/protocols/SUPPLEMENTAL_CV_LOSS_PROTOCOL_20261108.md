# Supplemental subject-wise CV and objective comparison v1

2026-11-08. User now requests fuller experimental validation, superseding the earlier figure-only choice. Preserve the delivered illustrated manuscript and every original experiment. New work is a post-hoc development robustness study, not a reset of the original final test or confirmation of a newly independent hypothesis.

## Data and split

Use only existing verified DaLiA S1-S12; exclude S13-S15 and all Wrist records from training, selection and new CV. Existing final/external scores must not determine folds, loss parameters, stopping or model choice. Outer subject folds, fixed now by ID:

|fold|train|inner development for checkpoint selection|outer evaluation|
|---|---|---|---|
|1|5,6,7,8,9,10|11,12|1,2,3,4|
|2|3,4,9,10,11,12|1,2|5,6,7,8|
|3|1,2,3,4,7,8|5,6|9,10,11,12|

Each person is evaluated once per seed/loss/method, never shares windows across partitions within a fold. This is three-fold outer subject evaluation with a fixed inner holdout, not full nested K-fold search. All twelve persons previously contributed to the original development/training process: report exploratory/post-hoc status at method-design level; no claim these are twelve wholly unseen people.

## Comparisons

Primary CV: C/G/D/D_without_c under stable logcosh, 3 folds x3 seeds42/43/44 x4 methods =36 fresh runs.
Objective sensitivity: G and D under additional MSE, MAE and Huber(delta=5 BPM), each same3folds/3seeds =54 fresh runs. Total90. Reuse the matching new CV logcosh arms for the fourth objective; never rerun duplicates. Existing CPU or GPU fixed-split weights are not controls for this new experiment.

Exact objectives on error e in BPM: logcosh=e+softplus(-2e)-ln2; MSE=e^2; MAE=abs(e); Huber=0.5e^2 if abs(e)<=5 else5*(abs(e)-2.5). Batch mean over windows; no per-objective normalization or hidden adaptive weighting. This evaluates objectives under a common optimizer contract, not each objective optimized over its own learning rates/delta. Keep instability/failure and all seeds visible.

## Fair training and checkpoint selection

All new arms use the same device: existing RTX4060 CUDA FP32 deterministic setup, no AMP/TF32; sequential workers,2 CPU threads. Existing frozen initial random backbone per seed may be copied, never trained best weights. Within fold/seed: identical initialization, fresh Adam AMSGrad lr0.001 for backbone/gate,weight_decay0,batch128, matching epoch permutations, all windows retained with existing singleton-tail treatment; original architecture/front-end unchanged.

200 full epochs maximum per arm,20 non-improving full-epoch checks. Compute actual batch count from each fold train set, not the old338. For ALL objectives select by the SAME inner-development equal-person MAE, FP64 aggregation and strict improvement. Raw logcosh/MSE/MAE/Huber validation values are not comparable across objectives. Do not mix the old logcosh-selection study into these paired estimates. Report actual updates and stop reason; common caps do not imply equal actual training.

Freeze all90 run identities, fold data catalogs, initial weights, configs, objective equations, code/source hashes and rules BEFORE first training. Do not inspect any outer result until every required arm has finished training and its inner-selected best checkpoint is locked. Then one registered outer evaluation per arm, keeping all windows/eligibility/failures; no tuning after outer scores. Original test and external results remain untouched.

## Analysis and execution boundary

Primary paired D-G and D-C under logcosh; D-full minus D-without_c separately. Within seed compute each outer person's MAE, then equal12-person mean. Keep all12person x3seed paired cells; folds/windows/seeds are not additional people. Objective effects are paired on exactly the same outer windows, and include D-G for each objective; no picking best loss after seeing outer data. Report loss x method table, coverage, histories, all arms including failures; no automatic inferential stars.

First produce an executable candidate and runtime/storage estimate based on actual prior runs/fold sizes. Only necessary new fold leakage/objective/selection/lifecycle checks, inheriting unchanged frontend/backbone evidence. Per-arm hard watchdog2h; one complete stage ceiling72h; resource gates unchanged. On budget/resource failure preserve incomplete status, do not silently truncate/declare convergence, clear ledger, resume weights, change folds or reduce seeds. No paid models, downloads of existing data, extra chats or automatic new tasks.

New external data acquisition is separately prepared and will have a source/units/synchronization/reference/duplicate-subject/eligibility protocol fixed before any score. New datasets must not be searched or selected for favorable method scores.


## 2026-11-08 v1.1 amendment before any training

The user requests the whole batch to continue independently of model quota and survive shutdown/restart. Interpret the requested complete batch as all90 arms; no new dataset results or training have been produced. This amendment explicitly supersedes the original no-resume operational restriction, not the scientific split/objective/seed/selection rules.

Operational cumulative ACTIVE stage ceiling is96h based on the observed67.25h full-cap estimate and80.70h planning allowance; per-arm2h,200epochs,3seeds and all90 identities remain unchanged. Exclude powered-off time but persist cumulative actual active seconds across restarts; never reset time budget on resume. This96h ceiling is a coordinator operational choice before training, not a user-provided exact time allowance or guaranteed completion. Original v1/72h candidate/freeze/receipt retained; implement and review a newv1_1 before executing.

Atomic two-generation full state checkpoints must preserve model/BN/optimizer/RNG/nextbatch/epoch accumulated losses/best/patience/run identities and budgets. Login-triggered independent Windows task resumes only an armed authorized run, with a unique process lock and complete-arm hash checks. Require real small interrupted-vs-continuous equivalence and parent-exit independence checks. Entire local pipeline continues without model calls between arms. Completion/irrecoverable failure produces one saved terminal event and one codex queue --resume attempt; callback quota/network/daemon failure must never fail or restart training. App wake is attempted, not guaranteed. No periodic model poll is used; existing review timer paused and preserved.

## Operational amendment recorded 2026-11-09

The user's 2026-11-08 instruction explicitly cancelled the per-arm two-hour limit and requested continuation from existing checkpoints. The implemented parallel_local_v1/POLICY.md supersedes the earlier sequential-worker and per-arm-time-limit statements above. The global ceiling remains 96 cumulative active worker-hours, charged as the sum of worker awake-active time; prior consumption and engineering debits are retained. Maximum 200 epochs, patience 20, batch 128, FP32, original optimizer, fixed split/seed/objective identities, and common inner-MAE selection remain unchanged. Runtime policy sidecars explicitly record the override; original checkpoint identities may still contain the historical 7,200-second option and are preserved for compatibility.

On 2026-11-09 the user delegated the choice of additional concurrency and requested useful concurrent research work. This authorizes a bounded engineering comparison and continuation under the existing experiment owner, not new scientific configurations or a fresh time budget. Two production workers were observed running; a third worker is only an engineering candidate until end-to-end throughput and resource evidence justify deployment. No outer result may be inspected early as part of this comparison.
