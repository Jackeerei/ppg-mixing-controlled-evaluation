# Committed development stopping histories

All90 registered development arms; source histories and summaries checked against each train_COMMIT SHA256. No model loading, new training/inference, final-test access or smoothing.

stopping_by_run.csv gives actual stopping epoch/update and selected best epoch/update. The selected epoch is the first strictly minimal inner subject-equal MAE, checked against recorded best_update and best_inner_mae. stopping_by_fold_method_objective.csv describes three seeds within each fold; means/medians are descriptive, not independent-subject evidence. Raw per-run curves are in inner_validation_curves_unsmoothed.csv. Compare MAE columns in bpm; raw objective columns have different scales/units and must not be compared across loss objectives. Curves have no interpolation, smoothing, or averaging. source_hashes.csv binds every source history/summary to its commit.

Shared optimizer settings, patience20 and epoch cap200 are execution controls. They do not isolate a pure effect of loss formulation or prove all runs sufficiently converged. A recorded early stop indicates20 validation checks without a strictly lower inner MAE under this recipe; it does not establish a global optimum. The retrospective development folds are not a new untouched final test.
