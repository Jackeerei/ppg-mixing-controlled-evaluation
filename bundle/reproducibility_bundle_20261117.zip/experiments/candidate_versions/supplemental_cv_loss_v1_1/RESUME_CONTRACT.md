## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run preparation
- Origin Date: 2026-11-08
- Verification Status: UNVERIFIED
- Version Label: supplemental_cv_loss_v1_1

User steering explicitly adds shutdown/login continuation and quota-independent execution. Root records the complete90-arm scope and authorizes a96-hour cumulative ACTIVE stage cap before training. The old v1 freeze64fcba80 and72h receipt remain unchanged. No fold, objective, seed, max200epoch, patience20, per-arm2h, optimizer or initial-state comparison is changed. The entire90-arm study remains post-hoc development robustness; S13-15/Wrist are excluded.

Checkpoint contract: after an optimizer boundary, at100updates or60sec first, at epoch/inner-selection boundaries and completion. Payload includes all model/BN/gate buffers, Adam/AMSGrad, Python/NumPy/CPU/allCUDA RNG, run/fold/loss/seed, epoch/next-batch/updates/loss_sum/seen, best innerMAE/model/update/patience, history/order hashes and active seconds. Source/config, input tensor/initial hashes, software/device/driver/determinism fingerprints bind identity. Two verified generations are indexed; temporary writes flush/fsync then atomic replace, prior index retained. Latest damage falls back; absent compatible checkpoint blocks blind restart. Corrupt files are retained as evidence. The usual uncommitted tail can repeat up to99updates; fallback after latest corruption can lose an additional generation. This cannot promise zero repeated GPU work after abrupt power loss.

A single armed study/runID/control is created once. Global OS lock and per-arm OS lock reject concurrent runs. Committed training/outer files have SHA identities and are verified before skipping. Active time is durably updated during compute; stage heartbeat approximately1sec (plus filesystem latency), per-arm active time also saved after optimizer boundaries. Offline time is excluded; prior counters are loaded, never reset. Exact sub-second accounting at abrupt power loss is not claimed. No-complete-checkpoint, identity, numerical or exhausted-budget failures block/disarm rather than silently restart. Both control and errors remain on disk.

All90 train commits are required before BEST_LOCK. Only then outer scoring; complete outputs skip, partial uncommitted output is rewritten from the same locked best without influencing method/seed selection. Local runner handles prepare→90training→best-lock→90outer→collect without any API/quota/model check. Final status/manifest precede callback. Callback uses one exclusive claim and one native codex queue --thread ROOT --message TEXT --resume; exit0 with warning is not resume success.429/nonzero/unavailable notification are preserved and cannot change training status/retry training. No periodic model calls or callback retries.

Windows planned task: Codex_PPG_SupplementalCV_Resume_v1_1; current-user InteractiveToken/Limited; AtLogon and on-demand; IgnoreNew. Exact program is ./experiments/.venv/Scripts/pythonw.exe; args are -B -X utf8 followed by absolute run.py and --resume-armed. With no matching armed control the task exits before torch import and never starts a new study. Use Task Scheduler as independent owner rather than assuming Popen/Start-Process escapes Codex JobObjects. No global power/BIOS/autologin changes. GPU does not compute while the machine is off. Parent-exit TaskHost probe is implemented and MUST actually pass after reviewed installation, before real arming/start. No task is yet installed at preparation time.

Executed checks: actual unchanged Q-PPG backbone/D gate/Adam, synthetic arrays only, continuous15 updates versus interrupt/restart at7 (non-epoch), CPU and deterministicCUDA exact weights/BN/optimizer/RNG/order/history/best/stale/metric; latest corruption fallback and identity mismatch rejection. Isolated completed-arm skip, OS double-start, active-time persistence, mockCLI429/nonzero/exit0warning and failed notification isolation passed. No CV outer arrays or old best inference involved. Review only the new lifecycle/resume/launcher difference; inherit folds/loss/model math evidence.

After one new necessary review receipt binds this version:

1. Run configure_supplemental_task_v1_1.py --install --receipt ABSOLUTE_RECEIPT. This installs the inert login task, does not arm/train.
2. Run probe_supplemental_taskhost_v1_1.py --execute --receipt ABSOLUTE_RECEIPT, let its launcher exit, verify RESULT worker_alive_after_launcher_exit=true, then remove ONLY its own LifecycleProbe task. If OS rejects registration, report it; do not claim independence or silently fall back to Codex-owned Popen.
3. Run run.py --arm ABSOLUTE_RECEIPT exactly once (receipt status passed, execution_freeze_sha256, approved_run_count90, study_active_budget_seconds345600). Then Start-ScheduledTask -TaskName Codex_PPG_SupplementalCV_Resume_v1_1. Check actual runner/worker PID/state once to substantiate startup; leave execution to the local task. No LLM polling thereafter.

PTT acquisition is separate, at most one bounded3600sec stage with the417.67MiB SHA/size plan; metadata already complete. It never authorizes an adapter or model scoring.
