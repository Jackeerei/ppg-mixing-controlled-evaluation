## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run preparation only
- Origin Date: 2026-11-07
- Verification Status: UNVERIFIED
- Version Label: final_evaluation_v1_execution_candidate

Only adapter/orchestration changes from reviewed Wrist inference: fixed S13-15 NPZ, 21-model registry with two separate sets, original Variant versus reviewed GateAblation selection, three-subject/three-seed aggregation, all candidate failure states and single-attempt ledger. Engine evaluate, score_predictions, frontend, backbone, and gates are imported unchanged; hashes bound in EXECUTION_FREEZE.json. Original preparation config and manifest remain unchanged and preparation-only. infer_vs_wrist.diff records the actual entry-point delta.

Default verification command (no torch/model/NPZ load, no final scores):
`experiments/.venv/Scripts/python.exe -B -X utf8 experiments/candidate_versions/final_evaluation_v1/infer.py`

Future one-time execution, only after the same pending independent review passes and coordinator dispatches:
`experiments/.venv/Scripts/python.exe -B -X utf8 experiments/candidate_versions/final_evaluation_v1/infer.py --execute --review review/FINAL_EVALUATION_ENTRY_RECEIPT_20261107.json`

Review receipt JSON must contain status=passed, execution_freeze_sha256 matching this candidate EXECUTION_FREEZE.json, and preparation_manifest_sha256 matching the original preparation manifest. Do not fabricate a receipt in this experiment chat. No weights are loaded in this preparation step. No execution ledger exists yet.

Outputs: all 21 arms preserve all 13007 candidate rows (initial not_started, then ok or model_failure), per-arm scores and original training device, aggregate.json with separate model sets/seed macro/pooled/per-subject metrics, subject_activity_metrics.csv, 45 paired_subject_seed_deltas.csv cells across five contrasts, input/frontend NPZ, source/config/review bindings, terminal and full MANIFEST. Failure/incomplete is preserved without restart or numerical retuning. 1800 seconds is a checked stage bound between arms, not a process-enforced hard timeout.
