# v1.2系统关机事件后的唯一全包重跑候选

此次只授权准备。原v1.1 freeze49f3、原正式ledger和中断包完整保留，不清账本、不resume D42、不拼接四组已完成输出。本版本如独立通过，必须从三seed原共享主干初态、新优化器重跑全部ABCGD×42/43/44，同一轮换顺序及完整12人数据；不用部分误差改变任何数值或方法。

engine.py、data_catalog.json、三份initial_backbone、整个implementation逐字节相同。protocol仅operations.attempt_ledger改为logs/round2_v1_2_attempts.json；单次尝试、338/67600、双人macro严格best/patience、所有资源边界不变。runner改动限新ledger/锁及receipt对shutdown_evidence_binding SHA和各旧事件文件SHA的检查；完整快照策略继承v1.1。

新增shutdown_evidence_binding.json绑定原关机报告、PARTIAL_EVIDENCE_MANIFEST、原消耗账本、独立复核关闭报告/机器证据。新回执须status=passed、当前execution_freeze_sha256、shutdown_evidence_binding_sha256，以及review_report/对应SHA。旧回执被拒绝。旧running只是保留的历史记录，不表示原任务仍运行。

新增launch.py/host_observer.py：启动前资源/进程/新版本ledger/锁检查，记录boot、PID创建时间和持续可用性说明；不修改电源设置或启动服务。10秒观察使用boot+PID创建时间，明确区分陈旧记录、PID复用和当前身份；正常退出或后续显式观察发现中断时追加绑定原启动记录SHA的外置终态，不覆写旧record/ledger，不自动重开。主机重启会同时结束观察程序，所以之后须显式观察，不能声称具备跨重启驻留能力。可用性说明是运行条件记录，不是新用户批准流程，也不保证不会关机。

合成差异检查继承并重定向单次ledger/完整快照检查，新增boot改变、PID消失/复用、外置终态原记录不变、旧回执拒绝。常规验证/资源前提与prepare子进程边界仍仅在隔离合成workspace中用替身；实际execute/Lock/ledger/copytree/hash保持真实，prepare边界截获，不启动实际子任务。其他数据和训练数学不重测、不重复下载/训练。
