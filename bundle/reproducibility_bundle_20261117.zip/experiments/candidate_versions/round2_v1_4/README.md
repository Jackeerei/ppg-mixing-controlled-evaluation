# 第二轮唯一执行器候选 v1.4：待独立审查，不是训练通过

首轮15组及负/混合结果保持不动。本版本只扩大至原名单S1–S10训练、S11/S12开发；两位开发人都参与选模，不能称最终独立测试。S13–S15不打开。本目录不可在通过回执前启动真实前端缓存或训练。数据清单与精确预算在全部12人准备后生成protocol.json/data_catalog.json；EXECUTION_FREEZE逐字节绑定执行器、配置、共享初始化、前端及合成证据。

R2-01：engine.evaluate先以FP64对每人全部窗计算mean logcosh，再对S11/S12等权平均为validation_macro_logcosh。严格更小才更新同一个best，patience也只用该量；同一次验证保留每人N/loss/MAE及macro/pooled。两人必须完整有限，一人失败是共同失败，不做nanmean或分别挑checkpoint。

R2-02：每个subject×seed×method留全窗输出。主要D-C/D-G（辅助D-A/D-B）保存2×3原始差值、每人三seed均值、再对两人等权均值，以及每seed双人macro差值和其三seed样本SD；不是n=6受试者，也不将重叠窗用于独立样本检验。缺任一注册组合不生成完整对比。aggregate保留15个状态行，逐窗核身份/参考/活动/时间/alpha及端点，失败停止后续组。

R2-03：subject升序、各人start升序拼接，全窗单次shuffle；独立生成器seed+1000003*epoch，各臂共享同seed批序前缀。训练按窗均匀，并非按人均匀，长训练记录权重更大；开发选模按人等权。batch128，最后128+1改为127+2，零丢窗、零重复、仍两次更新。每完整epoch验证，最大200完整epochs，patience20。B=ceil(Ntrain/128)，max_updates=200B，val_interval=B。部分轮失败不验证或选模。共享初态、新Adam、主干与gate实际组保持首轮设置，不支持续训。

R2-04：仅使用已绑定12人全部原始/NPZ/来源与窗口清单。未齐不启动子试验。资源估计只用合成shape，未读取真实开发误差；CPU两线程、batch128。配置按两次合成测时的较大p95估计最大训练+验证时间，再乘3并加600秒、向上整分钟，至少3600秒且至多21600秒；超过上界不接受配置，不声称估计保证完成。缓存准备独立子进程1800秒操作边界。内存至少2.5GiB及三倍已估数组+512MiB之较大者，磁盘至少10GiB；PKL原2.5GiB保护保持。训练/验证/输出和公共前端时间分别记录，均不是部署时延/能耗。

固定失败边界：每个版本只允许一次全包尝试，由排他锁内持久ledger记录。ledger非空（running/failed/completed任一）一律拒绝，换输出目录不能绕过。成功（含负结果）禁止重试；失败保留原包并定位原因，须另建新版本独立复核。本版本不重试，不恢复。设备/线程/数值规则改变须新版本。没有可靠优化器/RNG/游标恢复，best/last只有推理权重。共同准备失败15行not_run；某臂失败保留全部文件并停止后续，完整比较不成立。目录必须全新。

实际合成证据见executor/synthetic_*/checks_and_cost.json：不等N的macro/pooled反向选择；129/257尾批完整一次覆盖；真实优化器与注入选模标量的strict-best/patience；一个人缺失或非有限拒绝；部分轮失败无best/history；生产cache字段桥接与复用；配对缺项拒绝；官方4574主干D的batch128合成更新及有限测时。注入scalar只测试控制流，不代表HR效果。未改动的前端数学仍沿CI01已审实现，不重复声称独立数学验证。

公共入口executor/runner.py默认只核验冻结/数据并显示计划。执行须review目录JSON回执status=passed、execution_freeze_sha256精确匹配本版，并绑定review_report及其review_report_sha256。内部worker和prepare-worker仍核验回执。此回执是版本记录，不是身份签名。独立复核前不创建真实round2运行包；不修改首轮冻结或用其旧回执放行。

待复核入口：protocol.json → data_catalog.json → executor/runner.py → engine.py → 合成证据。特别检查完整两人同checkpoint选模、完整15组配对、采样尾批/实际Ni/更新数、共同数值与资源失败、ledger/无恢复、真实来源绑定及全部输出分母。数据取得与代码自检不等同模型有效或论文实验完成。

运行source完整复制所有冻结依赖（只忽略未绑定__pycache__），snapshot_manifest绑定冻结表及各项SHA，准备worker与训练worker均先核快照。旧configuration_builder.py仅为v1历史配置生成证据，不用于生成或运行本修订协议。

本版是已审关机事件后的全15组合新包候选，不复用原四臂结果，不resume D42。新增shutdown_evidence_binding.json固定旧关机报告、独立关闭报告及原账本哈希，新review回执还必须给出shutdown_evidence_binding_sha256。唯一未来启动入口executor/launch.py记录boot、launcher/runner创建时间、可持续运行说明并每10秒观察；中断时只写外置终态，不清账本或重开。系统重启会停止观察程序，后续显式运行host_observer.py识别陈旧running，不能声称跨重启常驻。运行前保持主机持续可用，单臂4140秒/准备1800秒是操作边界，15臂加准备上限口径合计63900秒（尚有校验/启动开销），并非预计时长或整包严格截止保证。不得改电源设置或启动额外服务。

L01/L02以当前launch.py/host_observer.py合同为准：启动意图只写一次，identity/terminal另存绑定其SHA；原事件文件不覆盖。观察故障记录降级并继续等待自有Popen，原runner界限不变，新增launcher观察上限72000秒后仅按已核boot/PID创建时间处置自有树，Popen原持有OS句柄不依赖复用PID。未知后代不得宣称已终止；写入故障通过stderr/可用日志如实标注未落盘。starting身份缺失由显式observer返回unknown并说明launcher是否仍存在，而非KeyError。

本版仅R2-L03事件原子发布/逐件容错；新回执前禁止执行。继承L01/L02等已审证据，本轮只运行check_event_publication.py窄回归，历史生命周期/账本脚本为来源留存，不重跑。见FIX_DIFF.md。
