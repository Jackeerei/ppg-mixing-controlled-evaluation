# v1.4关机处置后候选差异审查请求

请仅复核新版本操作差异。继承review/ROUND2_SHUTDOWN_EVIDENCE_FOLLOWUP_20261106.md及49f3已审数学/数据；不重做12人原始映射、NLMS数学或首轮训练。

重点：旧ledger/包不变，完整15组合新初态、不拼接/续训；新版本单次ledger/锁不可换目录绕过；旧关机与独立关闭事件哈希绑定；新回执不能由旧版本套用；boot/PID创建时间观察及外置终态原件不变；完整source冻结依赖可核。FIX_DIFF与合成check_revision产物提供证据。此请求不是执行许可。

如通过，请在review/提供新回执：status、execution_freeze_sha256、shutdown_evidence_binding_sha256、review_report、review_report_sha256。唯一候选启动命令（仅通过新回执后，由总协调派发）：

```powershell
experiments/.venv/Scripts/python.exe -B -X utf8 experiments/candidate_versions/round2_v1_4/executor/launch.py --review-receipt review/round2_v1_4_review_receipt_20261106.json --availability-note "Host expected to remain available for the complete registered run; no power settings changed"
```

需要时只观察已有记录（不启动/恢复任务）：

```powershell
experiments/.venv/Scripts/python.exe -B -X utf8 experiments/candidate_versions/round2_v1_4/executor/host_observer.py --record <actual_launch_record.json>
```

不存在跨重启服务。每个版本只能一个全包尝试；任何失败保留并反馈。4140秒每臂/1800秒准备是失败边界，不是预计完成时间。主机须持续开机可用，启动前由操作者记录预期可用性；本代码不改系统电源方案。不打开S13–S15，真实结果需独立审查后才可用于论文结论。

L01/L02以当前launch.py/host_observer.py合同为准：启动意图只写一次，identity/terminal另存绑定其SHA；原事件文件不覆盖。观察故障记录降级并继续等待自有Popen，原runner界限不变，新增launcher观察上限72000秒后仅按已核boot/PID创建时间处置自有树，Popen原持有OS句柄不依赖复用PID。未知后代不得宣称已终止；写入故障通过stderr/可用日志如实标注未落盘。starting身份缺失由显式observer返回unknown并说明launcher是否仍存在，而非KeyError。

本版仅R2-L03事件原子发布/逐件容错；新回执前禁止执行。继承L01/L02等已审证据，本轮只运行check_event_publication.py窄回归，历史生命周期/账本脚本为来源留存，不重跑。见FIX_DIFF.md。
