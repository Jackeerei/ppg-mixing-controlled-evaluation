# R2-L01/L02窄操作修复 v1.3

旧8ad2完整保留。数据、engine、implementation、三份初态、ABCGD/三seed/顺序、双人选模、338/67600及原runner资源界限不变；protocol仅版本ledger和必要launcher观察上限72000秒操作合同新增。

launch.main以完整try/except/finally拥有Popen至终态。Popen失败、快速退出/身份查询失败、身份持久化失败、observe和observations I/O异常均有明确处理：监看降级不重开，继续以持有的Popen等待原runner；最终异常或观察上限则安全处理自有树，并有界wait。对子代操作先验证boot与root创建时间，再验证子代创建时间/is_running；PID复用不枚举/终止无关树。Popen.terminate使用原OS句柄。无法核实后代或处理失败时如实记录unknown/error，不假称全部终止。没有跨重启服务或电源修改。

L02：意图JSON只用x模式写一次，绝不runner.write覆盖。身份、正常0/非0结束、启动/监看异常终态分别用x追加旁置，均绑定意图SHA，终态另引用身份事件SHA（未能持久化时明确None及stderr记录）。事件写入失败明确stderr及可用输出日志报告，不能用成功print掩盖。observer从绑定旁置解析，starting缺身份可解释为unknown并给launcher状态。

check_lifecycle.py调用实际main，替换常规审查/资源前提与Popen/psutil/睡眠边界，在隔离workspace测试正常0、非0、Popen失败、快速退出/身份失败、身份持久化失败、observe/observations开写异常、terminal持久化失败、上限自有树及PID复用；断言意图不改、退出有界、无实际子任务。继承单次ledger/跨进程锁/完整快照及旧回执拒绝，不重测数据/数学/真实四臂。
