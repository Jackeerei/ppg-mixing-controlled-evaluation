# R2-L03唯一窄修订 v1.4

保留v1.3 freeze8959及此前通过的L01/L02、数学/数据/12例main/账本/快照证据，不重复这些检查。engine/catalog/implementation/三初始化/5臂3seed/顺序/数值/338和67600/资源预算均不变；protocol仅新版本ledger路径。runner/launch仅改版本路径和输出文件前缀。

append_event先用唯一UUID .pending名x写完整内容、flush/fsync，关闭后原子os.replace发布到唯一最终JSON名；临时名不匹配最终JSON glob。任何半写/发布失败保留pending取证，不清理旧事件或原意图。

resolve逐件捕获JSON错误、不可读、错intent SHA/path、非object/缺字段/不合理terminal状态，记录具体路径和错误后继续。合法terminal存在返回并附invalid_events；否则使用合法identity或starting观察并明确terminal_status=unknown，不将坏terminal推断为完成。未发布pending也报告但不信任。CLI无法写观察旁置时stderr如实报告。

仅新增check_event_publication.py：真实launch.persist→真实append_event在json.dump实际写入并flush半JSON后抛错；identity半写+合法terminal、terminal半写+合法identity；纯坏/截断/错绑定/不可读/缺字段，原意图和已发布旧事件SHA不变，证据不删；原子发布失败保留完整pending。零真实子任务/缓存/训练。历史check_lifecycle/check_revision保留为继承来源，不在本轮重跑。
