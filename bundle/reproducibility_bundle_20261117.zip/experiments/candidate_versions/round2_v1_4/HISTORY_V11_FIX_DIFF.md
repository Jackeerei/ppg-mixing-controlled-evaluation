# R2-E01及冻结快照差异修复

旧round2_v1与freeze d634b5842ff1f34f54738e0ccb92a3ec39e948f872990e10b63ee946c6be7894保留。数据与原核心训练/指标/初态/前端不修改；338步每轮、67600上限、CPU2线程及资源门槛不变。

修订版只允许一次全包尝试。版本ledger固定为logs/round2_v1_1_attempts.json，锁为round2_v1_1.lock；首次创建running条目，结束只更新该条状态。任何非空ledger，无论running/failed/completed及新输出目录，一律拒绝，不再将failed当作可用旧回执再次运行的许可。失败后保留原包和事件，另建新版本并独立复核。成功负结果亦不可重跑。protocol/README同步maximum_whole_bundle_attempts=1。

source完整复制所有冻结依赖，只忽略未绑定__pycache__；不再忽略冻结中包含的synthetic_*。snapshot_manifest.json绑定冻结表SHA和逐项文件；创建后立即核验，prepare-worker/train-worker运行前也核验。source内可逐项自证，缺失/改变的依赖不得继续。

executor/check_revision.py为隔离合成复核入口：替代常规verify/receipt/resource前提与子进程边界，不生成真实passed回执；实际execute、Windows锁、ledger读写、copytree及快照核验保持原实现。空ledger首跑到达prepare但不启动子进程，注入失败后换输出路径仍拒绝；running/failed/completed均拒绝，保留原ledger/source。复制后的所有实际冻结文件（包括synthetic证据）逐项SHA/长度一致。输出只在reports独立SYNTHETIC目录，无真实缓存/训练。

configuration_builder.py与此前合成证据是继承的v1历史来源记录；本修订协议以已冻结protocol.json为唯一配置，不重新运行旧构建器。新freeze和本轮差异检查证据需独立复核，旧版未发回执不能放行修订版。
