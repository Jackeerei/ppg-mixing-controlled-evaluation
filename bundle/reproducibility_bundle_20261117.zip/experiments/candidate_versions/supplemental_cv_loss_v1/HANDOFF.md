## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run preparation
- Origin Date: 2026-11-08
- Verification Status: UNVERIFIED
- Version Label: supplemental_cv_loss_v1

90 fresh arms, S1-12 only, exact protocol folds/initial states/seeds. Shared new logcosh runs are not duplicated. Old S13-15 and Wrist are excluded. Existing reviewed label-free frontend caches are SHA-bound and reused. Preparation writes fixed per-fold train/inner/outer arrays; train workers read only train/inner. All arms select strict inner equal-person MAE, fresh original Adam/AMSGrad contract, deterministic CUDA FP32/no AMP/TF32,200 full epochs/patience20. Engine diff changes objective dispatch/selection/role labels/import path; original backbone/gates and batching/permutations inherited. All90 training summaries must complete before BEST_LOCK binds checkpoints; only then one outer evaluation per identity. Single stage ledger prevents restarting/resuming; per-child hard2h and remaining72h timeout, preparation1800s. Failed/unfinished identities remain in frozen roster; never count them as success.

Synthetic checks: objective analytic values/gradients at +/-1000 and Huber5 boundary passed CPU FP64 and CUDA FP32; imbalanced subject example MAE5 versus pooled<1.1, unique90 identities, fold disjointness and singleton retention passed. Lifecycle and new fold/objective/common-MAE release logic await one necessary independent check, no inherited full math re-audit. No real training or outer data loaded.

Prior six FULL deterministic CUDA logs imply all200-epoch linear67.252h, +20pct80.703h. Prior mean87.17epoch scenario29.311h is not a guarantee with new objectives/stopping. Thus72h feasibility uncertain: report before training and do not cut seeds/epochs. Arrays~0.743GiB plus scaled arm artifacts~0.471GiB; current resource snapshot in checks.json. Configuration contains exact rates/sourceSHA and folds.

Default candidate-only command:
experiments/.venv/Scripts/python.exe -B -X utf8 experiments/candidate_versions/supplemental_cv_loss_v1/run.py

Future execution ONLY after same necessary check passes and coordinator addresses budget concern:
experiments/.venv/Scripts/python.exe -B -X utf8 experiments/candidate_versions/supplemental_cv_loss_v1/run.py --execute --review review/SUPPLEMENTAL_CV_LOSS_ENTRY_RECEIPT_20261108.json

Review receipt: status=passed and execution_freeze_sha256 equal FREEZE.json. This experiment chat does not create review receipts. Single ledger does not yet exist. Outputs preserve histories, actual stopping, initial/batch/input hashes, inner and outer predictions, all12person x3seed contrasts and objective effects, seed macro and pooled. Post-hoc development robustness only; no new final validation claim.
