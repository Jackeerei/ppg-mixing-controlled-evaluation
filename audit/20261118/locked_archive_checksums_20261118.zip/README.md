# Locked archive checksum and identity audit, 2026-11-18

This is a minimal local release candidate, not a publication or permanent repository. It contains only SHA256 commitments, deidentified aggregate metadata, a deterministic exporter, and an independent stdlib-only verification program. Original archives remain unchanged. No signal arrays or trained checkpoints are loaded; no training, inference, model selection, outcome-metric recalculation or repeat final evaluation is performed. No raw signals, large checkpoints, individual window identities, individual reference/prediction values, personal absolute paths or credentials are distributed.

## What the commitments establish

1. **Manifest source:** archived final/external preparation-manifest bytes match the hash recorded in the original execution intent. The original candidate-window CSV hash matches its preparation manifest. Archived model/configuration bindings are separately hashed. The original result MANIFEST binds each fixed prediction CSV and arm summary. The verifier checks both these historical bindings and the new public hash commitments.
2. **Window identity:** canonical hashes of candidate and eligible identity tuples match between the existing preparation CSV and each fixed prediction CSV. Uniqueness is checked. Final identity fields: subject, window_id, start_sample_32hz, stop_sample_32hz, reference_label_index, activity. External identity fields: record, subject, activity, window_id, start_sample_256hz, stop_sample_256hz. Individual tuples are never released; only aggregate counts and digests appear in the public JSON.
3. **Fixed-output coverage:** input/reference availability and eligibility flags match; successful-status identity hashes equal eligible identity hashes. Final: 13,007 candidate/eligible rows, zero excluded, for each of 21 locked models over subjects13–15. External: 3,332 candidates, 3,320 eligible and12 excluded rows, for each of15 models over19 records and8 participants (IDs1,2,3,4,5,6,8,9). Those12 excluded rows remain in output CSVs and are not counted as successful predictions. Archive status fields, not newly computed numerical errors, establish coverage here.

86 selected original artifacts and36 arm outputs were checked. SHA256 commits to exact local archived bytes and does not establish independent authenticity, physical sensor synchronization, correct label construction, absence of historical leakage, numerical prediction validity, clinical accuracy or end-to-end retraining reproducibility. Byte hashes are sensitive to formatting/line endings. Original archived CSVs are not included in this release; checking those bytes requires access to the original archive. An owner of the public dataset cannot reproduce all hashes solely by downloading raw data: original model outputs, protocol versions and archived manifests are also needed. This audit verifies existing records; it does not create a new untouched test set.

## Canonical identity hashing

For each CSV row, retain exactly the listed identity-field text (no numeric rounding). Normalize availability flags `1`/`true` and `0`/`false` to Boolean values, case-insensitively. Reject duplicate identity tuples and eligibility that differs from the conjunction of input/reference availability. Sort identity tuples lexicographically as lists of strings, serialize the entire list using Python `json.dumps(sorted(rows), ensure_ascii=True, separators=(',', ':'))`, append exactly one LF, encode UTF8, then SHA256. Availability commitments use identity tuples with the three normalized Boolean flags appended. Eligible and successful-status commitments use their respective identity subsets. CSV row order does not affect these canonical commitments; the separate raw-byte commitments remain order-sensitive.

## Verification commands

Python3.13, standard library only; no NumPy, Torch, CUDA or network calls:

    python verify_locked_archives.py --archive-root <EXPERIMENTS_DIRECTORY> --manifest LOCKED_ARCHIVE_CHECKSUMS.json --report local_verification.json
    python test_metadata_verifier.py

The supplied archive-root must contain the original `results/` and `reports/` subdirectories referenced by relative paths in the JSON. The verifier imports no exporter or training/inference modules. Its output contains only counts and scope; it does not emit per-window values. It fails if hashes/byte sizes, manifest bindings, candidate identities, eligibility/availability or successful-status coverage change.

For an authorized archive owner, deterministic regeneration is available:

    python <EXPERIMENTS_DIRECTORY>/revision_20261118/build_locked_checksums.py

This exporter uses known relative archive locations and produces only new revision outputs. Two independent process exports were byte-identical: manifest SHA256 `85a5268226919e2fb8dc70eb08da5ac51502cda05e6f3ed201fbe0f00b58bbaf`. The local checks have been run. Negative fixtures reject duplicate window IDs, mismatched availability/eligibility, and eligible rows with failed output status. A separate reviewer should independently inspect the program and historical archive chain; this producer audit does not label itself an independent scientific review.

## Files

- `LOCKED_ARCHIVE_CHECKSUMS.json`: public candidate commitments and aggregate identity/coverage metadata.
- `verify_locked_archives.py`: independent-of-model verification implementation.
- `build_locked_checksums.py`: deterministic read-only archival metadata exporter.
- `test_metadata_verifier.py`: small synthetic negative checks, no actual outcome values.
- `CHECKS.json` and `DETERMINISM_CHECK.json`: local verification evidence.
- `SHA256SUMS.txt`: release-file checksums (excludes itself).

No existing experiment source, completed artifact, frozen model or original November17 reproducibility bundle was modified. The November17 bundle's tested development-prediction reanalysis is a separate scope. No conference submission, upload, paid service or permanent URL is implied by this local release.
