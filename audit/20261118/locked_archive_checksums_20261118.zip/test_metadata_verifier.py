"""Small adversarial checks for identity coverage, no real outcome values used."""
from pathlib import Path
import csv,tempfile,json
from verify_locked_archives import metadata
fields=['subject','window_id','start_sample_32hz','stop_sample_32hz','reference_label_index','activity']
base=dict(subject='13',window_id='0',start_sample_32hz='0',stop_sample_32hz='256',reference_label_index='0',activity='1',input_available='1',reference_available='1',eligible='1',prediction_status='ok')
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'fixture.csv'
 def write(rows):
  with p.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(base));w.writeheader();w.writerows(rows)
 write([base]);m=metadata(p,fields,True);assert m['success_rows']==1
 write([base,base])
 try:metadata(p,fields,True)
 except AssertionError:duplicate_rejected=True
 else:raise AssertionError('Duplicate was accepted')
 wrong=dict(base,eligible='0')
 write([wrong])
 try:metadata(p,fields,True)
 except AssertionError:flag_mismatch_rejected=True
 else:raise AssertionError('Availability mismatch accepted')
 wrong=dict(base,prediction_status='failed');write([wrong])
 try:metadata(p,fields,True)
 except AssertionError:eligible_failure_rejected=True
 else:raise AssertionError('Eligible inference failure accepted')
print(json.dumps({'duplicate_rejected':duplicate_rejected,'availability_mismatch_rejected':flag_mismatch_rejected,'eligible_failure_rejected':eligible_failure_rejected}))
